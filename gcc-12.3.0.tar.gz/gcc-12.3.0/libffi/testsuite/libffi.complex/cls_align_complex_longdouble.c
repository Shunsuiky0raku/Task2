/* Area:	ffi_call, closure_call
   Purpose:	Check structure alignment of complex.
   Limitations:	none.
   PR:		none.
   Originator:	<vogt@linux.vnet.ibm.com>.  */

/* { dg-do run } */

#include "complex_defs_longdouble.inc"
#include "cls_align_complex.inc"
