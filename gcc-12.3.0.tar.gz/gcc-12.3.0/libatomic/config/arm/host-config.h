/* Avoiding the DMB (or kernel helper) can be a good thing.  */
#define WANT_SPECIALCASE_RELAXED

#include_next <host-config.h>
