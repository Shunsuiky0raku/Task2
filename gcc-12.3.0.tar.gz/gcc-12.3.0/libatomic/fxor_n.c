#define NAME	xor
#define OP(X,Y)	((X) ^ (Y))
#include "fop_n.c"
